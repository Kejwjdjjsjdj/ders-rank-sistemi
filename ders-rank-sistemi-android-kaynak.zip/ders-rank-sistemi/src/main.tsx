import React from 'react';import{createRoot}from'react-dom/client';import App from './App';import './style.css';createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>);

if ('serviceWorker' in navigator && import.meta.env.PROD) { window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js').catch((error) => console.error('Çevrimdışı destek etkinleştirilemedi:', error)); }); }
