# Ders Rank Sistemi 4.0 — Android APK oluşturma

Bu kaynak paketi Capacitor ile gerçek Android uygulamasına dönüştürmeye hazırlandı. Uygulama kimliği `com.dersrank.sistemi` olarak ayarlanmıştır.

## Android Studio ile APK oluşturma
1. Bilgisayara Node.js 22 ve Android Studio (Android SDK dahil) kurun.
2. Bu klasörde terminal açın ve çalıştırın:
   ```bash
   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
3. Android Studio'da Gradle eşitlemesi tamamlandıktan sonra **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin.
4. Debug APK genellikle `android/app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.

## GitHub Actions ile APK oluşturma
1. Projeyi kendi GitHub deponuza yükleyin.
2. **Actions** sekmesinden **Build Android APK** iş akışını seçin ve **Run workflow**'a basın.
3. İş bitince `ders-rank-sistemi-debug-apk` adlı artifact'i indirin; içinde `app-debug.apk` bulunur.

## Notlar
- Bu paket Android APK dosyasının kendisi değildir; APK üretmek için Android SDK/Gradle ve npm bağımlılıklarının internet üzerinden kurulması gerekir.
- Bu çalışma ortamında Android SDK/Gradle bulunmadığından ve npm bağımlılıkları indirilemediğinden APK derlemesi burada tamamlanamadı.
- Debug APK test amaçlıdır. Play Store dağıtımı için imzalı release APK/AAB oluşturulmalıdır.
- Çalışma kayıtları mevcut tasarımda cihaz/tarayıcı yerel depolamasında tutulur; otomatik bulut eşitlemesi yoktur.
