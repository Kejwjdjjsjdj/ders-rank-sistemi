# Ders Rank Sistemi 4.0

Türkçe arayüzlü, React + TypeScript + Vite ile hazırlanmış, localStorage tabanlı ders çalışma takip uygulaması.

## Gereksinimler
- Node.js 20.19+ veya 22.12+
- npm

## Kurulum ve başlatma
```bash
npm install
npm run dev
```
Vite'ın yazdırdığı yerel adresi tarayıcıda açın (genellikle `http://localhost:5173`).

## Derleme ve test
```bash
npm run build
npm test
npm run preview
```

## Veri modeli ve mimari
- `src/config/game.ts`: dokuz ders, rank eşikleri, seviye başlıkları ve varsayılan ayarlar.
- `src/lib/engine.ts`: rank/EXP, seviye atlama, günlük seri, görev ve rank dondurma iş mantığı.
- `src/lib/storage.ts`: localStorage okuma/yazma ve JSON yedek doğrulaması.
- `src/types/index.ts`: uygulama veri tipleri.
- `src/App.tsx`: Türkçe ekranlar ve kullanıcı etkileşimleri.
- `src/style.css`: responsive koyu tema.

Veri anahtarı: `ders-rank-sistemi-v4`. Veriler tarayıcıda yerel olarak saklanır; farklı tarayıcı/cihazlara otomatik senkronize olmaz. Yedekleme için Ayarlar > JSON dışa aktar kullanın.

## Önemli uygulama notları
- Eski genel profil (Bronz III, -18 net EXP, 73 doğru, 41 yanlış, 0 tekrar sayfası) ayrı tutulur; derslere kopyalanmaz.
- Doğrulanmış ders geçmişi olmadığı için dokuz ders sıfır kayıtla başlar ve istatistikler kayıt oluşana kadar çizgi/0 yerine `—` veya `Henüz kayıt yok` gösterir.
- Rank eşikleri `src/config/game.ts` içindeki `RANKS` dizisinde düzenlenir. Katsayılar arayüzde gösterilmez ve `src/lib/engine.ts` içindedir.
- Sezon kartları oluşturma/arşivleme ve aktif sezon seçimini destekler. Sezon bazlı kayıtları ayrı ayrı sınıflandıran geçmiş filtresi henüz tamamlanmış değildir; kart metrikleri genel toplamı gösterir.
- Görevler eklenebilir; varsayılan görev önerileri vardır. Günlük görev ilerlemesi kayıtlarla ölçülür. Haftalık görevlerde haftaya özel otomatik yenileme henüz uygulanmamıştır.
- Rank dondurma kapsamı ayarı saklanır; mevcut kontrol tüm dersleri tarar. Dondurma kuralı atlanan takvim günü algılandığında 100 soruluk koruma başlatır.
- Seviye atlama bonusu seviye başına bir kez uygulanır. Seviye EXP'si soru toplamıyla artar; eski doğrulanmamış seviye değerleri uydurulmamıştır.
- Bu uygulama yerel bir istemci uygulamasıdır; hesap girişi, bulut yedeği veya çok cihazlı eşitleme içermez.


## Telefon uygulaması olarak kurulum (PWA)

Bu proje Android ve iPhone'da ana ekrana eklenebilen bir web uygulaması (PWA) olarak yapılandırılmıştır. Bir web adresinde HTTPS üzerinden yayımlandığında:

- **Android (Chrome):** siteyi aç → menü (⋮) → **Uygulamayı yükle** veya **Ana ekrana ekle**.
- **iPhone (Safari):** Paylaş → **Ana Ekrana Ekle**.

Yerel geliştirme: `npm install`, ardından `npm run dev`. Telefonda test etmek için bilgisayar ve telefon aynı Wi-Fi ağına bağlıyken Vite'ın gösterdiği yerel ağ adresini açabilirsin. Ana ekrana yükleme için uygulamanın HTTPS üzerinden yayımlanması gerekir. Bu paket Android APK dosyası değildir; telefona kurulabilen PWA'dır.

### Tekrar videosu EXP kuralı
Her tamamlanan tekrar videosu **+5 rank EXP** kazandırır. Çalışma kaydında izlenen video sayısı girilir; eski kayıtlar için bu alan sıfır kabul edilir.
